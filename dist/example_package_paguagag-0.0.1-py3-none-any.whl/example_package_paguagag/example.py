def add_one(number):
    # Add one to the number
    return number + 1

def add_two(number):
    # Add two to the number
		return number + 2

def add_three(number):
		# Add three to the number
		return number + 3

def add_four(number):
		# Add four to the number
		return number + 4